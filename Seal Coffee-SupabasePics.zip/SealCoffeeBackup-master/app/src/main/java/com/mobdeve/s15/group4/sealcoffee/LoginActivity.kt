package com.mobdeve.s15.group4.sealcoffee

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class LoginActivity : AppCompatActivity() {

    private val auth by lazy { FirebaseAuth.getInstance() }
    private val firestore by lazy { FirebaseFirestore.getInstance() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Check if user is already logged in and fetch their role from Firestore
        val currentUser = auth.currentUser
        if (currentUser != null) {
            lifecycleScope.launch {
                fetchRoleAndRoute(currentUser.uid)
            }
            return
        }

        setContentView(R.layout.activity_login)

        val emailInput = findViewById<EditText>(R.id.emailInput)
        val passwordInput = findViewById<EditText>(R.id.passwordInput)
        val loginButton = findViewById<Button>(R.id.loginButton)
        val signUpLink = findViewById<TextView>(R.id.signUpLink)

        loginButton.setOnClickListener {
            val email = emailInput.text.toString().trim()
            val password = passwordInput.text.toString()

            emailInput.error = null
            passwordInput.error = null

            if (email.isEmpty() || password.isEmpty()) {
                if (email.isEmpty()) emailInput.error = getString(R.string.email_required)
                if (password.isEmpty()) passwordInput.error = getString(R.string.password_required)
                return@setOnClickListener
            }

            loginButton.isEnabled = false

            // Authenticate with Firebase Auth
            auth.signInWithEmailAndPassword(email, password)
                .addOnSuccessListener { authResult ->
                    val uid = authResult.user?.uid
                    if (uid != null) {
                        // Fetch the role from Firestore using the user's UID
                        lifecycleScope.launch {
                            fetchRoleAndRoute(uid)
                        }
                    } else {
                        loginButton.isEnabled = true
                        Toast.makeText(this, "Authentication failed: Missing User UID", Toast.LENGTH_LONG).show()
                    }
                }
                .addOnFailureListener { exception ->
                    loginButton.isEnabled = true
                    Toast.makeText(
                        this@LoginActivity,
                        "Login failed: ${exception.localizedMessage ?: getString(R.string.invalid_credentials)}",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }

        signUpLink.setOnClickListener {
            startActivity(Intent(this, SignUpActivity::class.java))
        }
    }

    private suspend fun fetchRoleAndRoute(uid: String) {
        try {
            val documentSnapshot = firestore.collection("users").document(uid).get().await()
            val role = documentSnapshot.getString("role") ?: "customer"
            checkUserRoleAndRoute(role)
        } catch (e: Exception) {
            // Fallback to customer dashboard if Firestore fetch fails
            Toast.makeText(this, "Welcome Customer!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, CustomerMenuActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish()
        }
    }

    private fun checkUserRoleAndRoute(role: String) {
        if (role.equals("staff", ignoreCase = true)) {
            Toast.makeText(this, "Welcome Staff!", Toast.LENGTH_SHORT).show()
            // Route to your Staff Dashboard activity when implemented
            // startActivity(Intent(this, StaffDashboardActivity::class.java).apply {
            //     flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            // })
            finish()
        } else {
            Toast.makeText(this, "Welcome Customer!", Toast.LENGTH_SHORT).show()
            startActivity(Intent(this, CustomerMenuActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
            finish()
        }
    }
}