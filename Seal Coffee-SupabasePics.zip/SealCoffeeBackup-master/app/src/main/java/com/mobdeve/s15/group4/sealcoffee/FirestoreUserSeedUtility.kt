package com.mobdeve.s15.group4.sealcoffee

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object FirestoreUserSeedUtility {

    data class SeedUser(
        val email: String,
        val pass: String,
        val fullName: String,
        val role: String // "customer" or "staff"
    )

    fun seedUsersIfNeeded() {
        val auth = FirebaseAuth.getInstance()
        val db = FirebaseFirestore.getInstance()
        val usersRef = db.collection("users")

        val seedUsers = listOf(
            Triple(SeedUser("mika.santos@gmail.com", "Coffee123!", "Mika Santos", "customer"), "2002-03-14", "+63 917 555 0148"),
            Triple(SeedUser("carlo.staff@sealcoffee.com", "Staff123!", "Carlo Dela Cruz", "staff"), "1999-08-09", "+63 917 555 0192"),
            Triple(SeedUser("cheska.martinez@gmail.com", "CoffeeNo1!", "Cheska Martinez", "customer"), "2001-11-20", "+63 918 555 0234"),
            Triple(SeedUser("steven.universe@gmail.com", "Cookie123!", "Steven Universe", "customer"), "2000-05-15", "+63 919 555 0389")
        )

        for ((user, birthDate, contactNumber) in seedUsers) {
            usersRef.whereEqualTo("email", user.email).get()
                .addOnSuccessListener { snapshot ->
                    if (snapshot.isEmpty) {
                        auth.createUserWithEmailAndPassword(user.email, user.pass)
                            .addOnSuccessListener { authResult ->
                                val uid = authResult.user?.uid ?: return@addOnSuccessListener

                                val userDoc = mapOf(
                                    "uid" to uid,
                                    "email" to user.email,
                                    "fullName" to user.fullName,
                                    "birthDate" to birthDate,
                                    "contactNumber" to contactNumber,
                                    "role" to user.role
                                )

                                usersRef.document(uid).set(userDoc)
                                    .addOnSuccessListener {
                                        Log.d("UserSeed", "Seeded user successfully: ${user.email}")
                                    }
                                    .addOnFailureListener { e ->
                                        Log.e("UserSeed", "Failed to save user profile for ${user.email}", e)
                                    }
                            }
                            .addOnFailureListener { e ->
                                Log.w("UserSeed", "Auth creation skipped/failed for ${user.email}: ${e.localizedMessage}")
                            }
                    }
                }
        }
    }
}