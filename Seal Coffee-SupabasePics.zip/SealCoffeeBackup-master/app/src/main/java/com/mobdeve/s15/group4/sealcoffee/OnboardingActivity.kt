package com.mobdeve.s15.group4.sealcoffee

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class OnboardingActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        // Trigger the seeder when the app boots up
        FirestoreSeedUtility.seedInfoIfNeeded()

        // Check if user is already logged in -> bypass onboarding completely
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Optional: Set a lightweight loading layout or keep view hidden
            // until routing finishes to prevent a blank white flash.
            checkUserRoleAndRoute(currentUser.uid, currentUser.email)
            return
        }

        setContentView(R.layout.activity_onboarding)

        val getStarted = findViewById<Button>(R.id.getStartedButton)
        getStarted.setOnClickListener {
            startActivity(Intent(this, LoginActivity::class.java))
        }
    }

    private fun checkUserRoleAndRoute(uid: String, email: String?) {
        firestore.collection("users").document(uid).get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val role = document.getString("role") ?: "customer"
                    routeUserByRole(role)
                } else {
                    // Fallback if auth exists but firestore doc is missing
                    fallbackRouteByEmail(email)
                }
            }
            .addOnFailureListener {
                fallbackRouteByEmail(email)
            }
    }

    private fun fallbackRouteByEmail(email: String?) {
        val role = if (email != null && (email.contains("staff", ignoreCase = true) || email.endsWith("@sealcoffee.com"))) {
            "staff"
        } else {
            "customer"
        }
        routeUserByRole(role)
    }

    private fun routeUserByRole(role: String) {
        val intent = if (role.equals("staff", ignoreCase = true)) {
            // TODO: Replace with your Employee/Staff Dashboard Activity when ready
            // Intent(this, StaffDashboardActivity::class.java)
            Intent(this, CustomerMenuActivity::class.java) // Temporary fallback until staff activity exists
        } else {
            Intent(this, CustomerMenuActivity::class.java)
        }
        startActivity(intent)
        finish()
    }
}